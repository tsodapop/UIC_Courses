Name: Jonathan Tso
UIN: 662758603
NetID: jtso2

Partner: Jonas Szum

The following code provided answers up to 18/25 of the points. 
No special care needs to be taken care of to run the code. 
Simply python autograder.py should do.